import pandas as pd
import numpy as np
COLUMNS = [
"age", "workclass", "fnlwgt", "education", "education_num",
"marital_status", "occupation", "relationship", "race", "gender",
"capital_gain", "capital_loss", "hours_per_week", "native_country",
"LABELS"
]

df_data = pd.read_table('./data-sets/adult.data.txt', sep=',', skipinitialspace=True)